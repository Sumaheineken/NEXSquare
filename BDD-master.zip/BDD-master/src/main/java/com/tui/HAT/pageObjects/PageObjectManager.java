package com.tui.HAT.pageObjects;

import org.openqa.selenium.WebDriver;


public class PageObjectManager {

    private WebDriver driver;

    private LoginPage loginPage;
    private Facebook facebook;

private Nex nex;




    private SampleReferencePage sampleReferencePage;



    public PageObjectManager(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage getLoginPage() {
        return (loginPage == null) ? new LoginPage(driver) : loginPage;
    }

    public Nex getNex() {
        return (nex == null) ? new Nex(driver) : nex;
    }



    public SampleReferencePage getSampleReferencePage() {
        return (sampleReferencePage == null) ? new SampleReferencePage(driver) : sampleReferencePage;
    }



}
