package com.tui.HAT.core.enumManage;


public enum TestDataContext {
    REQUEST_ID,
    GLOBAL_ID,
    SYNDICATION_STATUS

}
