package com.tui.HAT.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//div[@id='cookies-content']//a[@id='AcceptReload']")
    private WebElement cookie;

    @FindBy(xpath = "//*[@class='tagus-dropdown tagus-dropdown--position-bottom tagus-dropdown--align-left'] ")
    private WebElement hoverCountry;

    @FindBy(xpath = "//ul[@class='tagus-dropdown__list']/li/button[normalize-space()='Show all languages']")
    private WebElement hoverCountrytiy;

    @FindBy(xpath = "//div[5]//p[1]")
    private WebElement clickCountry;

    @FindBy(xpath = "//span[@class='tagus-typo--desktop tagus-typo tagus-typo--bold tagus-typo--s'][normalize-space()='Accedi / Registrati']")
    private WebElement countryText;

    @FindBy(xpath = "//input[@id='search-text-input-field1']")
    private WebElement inputDest;

    @FindBy(xpath = "(//span[@class='tui-icon-button__content'][normalize-space()='RICERCA'])[1]")
    private WebElement clickSearch;

    @FindBy(css = "(//div[@class='date-picker detailpage__datepicker search-start__dates'])[1]")
    private WebElement dateSelect;
    @FindBy(css = "//a[@title='Verifica disponibilità']")
    private WebElement addTocart;

    @FindBy(css = "//div/time[@class='date-range-selection__month-name']")
    private WebElement monthSel;

    @FindBy(css = "//section/h1[@class='tagus-typo tagus-typo--black tagus-typo--heading tagus-typo--h1 tagus-typo--l']")
    private WebElement verifyitalytest;

    @FindBy(xpath = "//*[@id='search-text-input-field1']")
    private WebElement searchPage2;
    @FindBy(xpath = "//section/h5[normalize-space()='Popular']")
    private WebElement filPopular;
    @FindBy(xpath = "//section/h5[normalize-space()='Amenities']")
    private WebElement filAmenities;
    @FindBy(xpath = "//section/h5[normalize-space()='Board Types']")
    private WebElement filBoard;
    @FindBy(xpath = "(//*[@class='date-picker detailpage__datepicker search-start__dates'])[1]/button")
    private WebElement datepicker;

    @FindBy(xpath = "//*[@class='date-range-selection__month-name']")
    private WebElement datepickermonth;
    @FindBy(xpath = "  (//*[@class='tui-icon-button__content'])[2]")
    private WebElement arrowup;
    @FindBy(xpath = "//h3[@class='tagus-typo tagus-typo--heading tagus-typo--h3']")
    private WebElement clickanywhere;


    public void addCookies() {
        cookie.click();
    }

    public void verifyEng() {
        verifyTextPresentOnPage("Hotels");
    }

    public void selectItaly() {
        moveToElement(hoverCountry);
        hoverCountrytiy.click();
        waitForElementClickable(clickCountry);
        clickCountry.click();
    }

    public void verifyItalian() {
        verifyText(countryText, "Accedi / Registrati");
        verifyTextPresentOnPage("Scegli una destinazione");

    }

    public void searchforHotel(String hotelname) {
        enterValueOnElement(inputDest, hotelname);
clickanywhere.click();
        clickSearch.click();


    }

    public void windowHandle() {
        String pwindow = driver.getWindowHandle();
        Set<String> chi = driver.getWindowHandles();
        //Iterator <String> i1=chi.iterator();
        for (String hand : chi) {
            driver.switchTo().window(hand);


        }

    }

    public void verifyfst() {
        verifyText(addTocart, "Verifica disponibilità");
        clearOnElement(searchPage2);
        enterValueOnElement(searchPage2, "Rompin");
        searchPage2.click();
        verifyText(addTocart, "Verifica disponibilità");
    }
    public void removeHotel() {

        clearOnElement(searchPage2);
        enterValueOnElement(searchPage2, "Rompin");
        searchPage2.click();
        driver.quit();
       // verifyText(addTocart, "Verifica disponibilità");
    }

    public void verifyfilterNames() {
        verifyText(filPopular,"Popular");
        verifyText(filAmenities,"Amenities");
        verifyText(filBoard,"Board Types");

    }
    public void searchAnother()
    {
        clearOnElement(searchPage2);
        enterValueOnElement(searchPage2, "Rompin");
        searchPage2.click();
        //mouseDoubleClick(searchPage2);
        verifyText(addTocart, "Verifica disponibilità");
    }
    public void selectDates(String monthyear,String day,String today) throws InterruptedException {
        Date dd = new Date(1);
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy");
        String date = formatter.format(dd);
        String splitter[] = date.split("-");
        String month_year = splitter[1];
        day = splitter[0];

        waitForElementClickable(datepicker);
        datepicker.click();




        List<WebElement> elements = driver.findElements(By.xpath("//*[@class='date-range-selection__month-name']"));

        for (int i=0; i<elements.size();i++)
        {
            System.out.println(elements.get(i).getText());

            //Selecting the month
            if(elements.get(i).getText().equals(month_year))
            {

                //Selecting the date
                List<WebElement> days = driver.findElements(By.xpath("//*[@class='calendar-month date-range-selection__month-days']"));

                for (WebElement d:days)
                {
                    System.out.println(d.getText());
                    if(d.getText().equals(day))
                    {
                        waitForElementClickable(d);
                        d.click();
                        Thread.sleep(10000);
                        return;
                    }
                }
//today
                List<WebElement> todays = driver.findElements(By.xpath("//*[@class='calendar-month date-range-selection__month-days']"));

                for (WebElement td:todays)
                {
                    System.out.println(td.getText());
                    if(td.getText().equals(today))
                    {
                        waitForElementClickable(td);
                        td.click();
                        Thread.sleep(10000);
                        return;
                    }
                }
            }

        }


    }
}


