package com.tui.HAT.core.businessComponents;


public class Actions {
}
