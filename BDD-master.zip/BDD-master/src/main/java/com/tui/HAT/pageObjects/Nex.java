package com.tui.HAT.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class Nex extends BasePage {

    public Nex(WebDriver driver) {
        super(driver);
    }
    @FindBy(xpath = "(//div[@class='form-group floating-label'])[1]/input")
    private WebElement sername;

    @FindBy(xpath = "(//div[@class='form-group floating-label'])[2]/input")
    private WebElement pasw;
    @FindBy(xpath = "//button[@id='log-btn']")
    private WebElement loginbutton;
    @FindBy(xpath = "//div[@class='user-photo-newui']")
    private WebElement verify;

    @FindBy(xpath = "//a[@id='hr']")
    private WebElement clickstaffadd;

    @FindBy(xpath = "//li[@id='link_addStaff']")
    private WebElement clickadddetails;
    @FindBy(xpath = "//input[@id='staffFullName']")
    private WebElement nameStaff;
    @FindBy(xpath = "//input[@id='dob']")
    private WebElement inpdob;
    @FindBy(xpath = "//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[4]/a")
    private WebElement datedob;
    @FindBy(xpath = "//input[@id='email']")
    private WebElement email;
    @FindBy(xpath = "//input[@id='salaryStartDate']")
    private WebElement salarycick;
    @FindBy(xpath = "//*[@id='ui-datepicker-div']/table/tbody/tr[5]/td[5]/a")
    private WebElement dateclick;
    @FindBy(xpath = "//button[@id='submitButton']")
    private WebElement clicksave;

    @FindBy(xpath = "//li[@id='link_editStaff']")
    private WebElement editsts;

    @FindBy(xpath = "//input[@id='staffRegisterNoOrName']")
    private WebElement edituser;

    @FindBy(xpath = "//button[@id='staffSearch']")
    private WebElement cickSearch;

    @FindBy(xpath = "//input[@id='joinDate']")
    private WebElement joindate;
    @FindBy(xpath = "//*[@id='ui-datepicker-div']/table/tbody/tr[3]/td[5]/a")
    private WebElement clickjoin;
    @FindBy(xpath = "//*[@id='itemrow']/tbody/tr/td[3]")
    private WebElement veriitem;

    @FindBy(xpath = "//span[text()='Fee Configuration']")
    private WebElement feeStructure;
    @FindBy(xpath = "//div[@class='mat-form-field-infix']/input[@id='searchInput']")
    private WebElement searcin;

    @FindBy(xpath = "(//button[@class='mat-icon-button mat-button-base'])[1]/span")
    private WebElement searchbutton;
    @FindBy(xpath = "//span[@class='mat-expansion-indicator ng-tns-c26-5 ng-trigger ng-trigger-indicatorRotate ng-star-inserted']")
    private WebElement expand;

    @FindBy(xpath = "(//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[4]")
    private WebElement seect;

    @FindBy(xpath = "(//button[@class='submit-btn mat-flat-button mat-button-base mat-accent'])[3]")
    private WebElement pay;



    public void login(String username, String psw) throws InterruptedException {
sername.sendKeys(username);
pasw.sendKeys(psw);
loginbutton.click();
        Thread.sleep(10000);
waitForElementPresent(verify);
    }

    public void save(String name,String emailid) throws InterruptedException{
        Thread.sleep(10000);
        waitForElementClickable(clickstaffadd);
clickstaffadd.click();
waitForElementClickable(clickadddetails);
clickadddetails.click();
waitForElementPresent(nameStaff);
nameStaff.sendKeys(name);
waitForElementClickable(inpdob);
inpdob.click();
waitForElementClickable(datedob);
datedob.click();
        waitForElementPresent(joindate);
        joindate.click();
        waitForElementClickable(clickjoin);
        clickjoin.click();
waitForElementPresent(email);
email.sendKeys(emailid);
waitForElementClickable(salarycick);
salarycick.click();
waitForElementClickable(dateclick);
dateclick.click();

clicksave.click();
    }

    public void eave(String name) {
        waitForElementClickable(editsts);
        editsts.click();
        waitForElementPresent(edituser);
        edituser.sendKeys(name);
        waitForElementClickable(cickSearch);
cickSearch.click();
waitForElementPresent(veriitem);
    }

    public void feeStructur() throws InterruptedException {
        waitForElementClickable(feeStructure);
        Thread.sleep(10000);
        feeStructure.click();
    }
    public void searchid(String id) throws InterruptedException {
        waitForElementClickable(searcin);
        searcin.sendKeys(id);
        Thread.sleep(10000);
        searchbutton.click();
        Thread.sleep(20000);
expand.click();

waitForElementClickable(seect);
seect.click();
waitForElementClickable(pay);
pay.click();
    }
}