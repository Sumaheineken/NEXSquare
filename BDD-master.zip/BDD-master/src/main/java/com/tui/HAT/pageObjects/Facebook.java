package com.tui.HAT.pageObjects;

import org.openqa.selenium.WebDriver;

public class Facebook extends BasePage{
    public Facebook(WebDriver driver) {
        super(driver);
    }
}
