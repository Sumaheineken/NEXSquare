package com.tui.HAT.stepDefinitions.MasterData;

import com.tui.HAT.cucumberUtil.TestContext;
import cucumber.api.java.After;
import cucumber.api.java.Before;


public class CommonStepDefinitions {

    TestContext testContext;
    public CommonStepDefinitions(TestContext context){
        testContext=context;
    }

    @Before
    public void beforeScenario(){

    }

    @After
    public  void afterScenario(){
        testContext.getWebDriverSession().quitDriver();
    }

}
