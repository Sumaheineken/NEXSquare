package com.tui.HAT.runner;



import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/MasterData"}, plugin = {
        "pretty", "html:target/reports/cucumber"}, glue = "com.tui.HAT.stepDefinitions"
)
public class RunCucumber {
}