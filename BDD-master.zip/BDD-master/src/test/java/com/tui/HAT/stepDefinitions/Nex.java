package com.tui.HAT.stepDefinitions;

import com.tui.HAT.cucumberUtil.TestContext;
import com.tui.HAT.cucumberUtil.TestContextManager;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Nex extends TestContextManager {

    public Nex(TestContext context) {
        super(context);
    }

    @Given("^Login to Facebook1(.*),(.*)$")
    public void login_as_LDR_Vendor1(String userName, String psw) {
        // loginPage.login(userName, psw);
       // loginPage.addCookies1();

    }



}